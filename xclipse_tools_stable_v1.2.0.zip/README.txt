Xclipse Tools Stable v1.2.0

This release adds support for compressed texture formats BC4, BC5, BC6H, BC7 (BPTC) exposed via Vulkan.

Installation:
1. Transfer the zip to your device.
2. In Winlator, Settings → AdrenoTools GPU Drivers → Install → select this zip.
3. Enable "Xclipse Tools Stable v1.2.0".
4. Restart container and enjoy enhanced texture format support!
